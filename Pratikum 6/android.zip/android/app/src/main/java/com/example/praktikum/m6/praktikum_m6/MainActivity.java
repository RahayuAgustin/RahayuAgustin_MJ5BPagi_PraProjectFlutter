package com.example.praktikum.m6.praktikum_m6;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
